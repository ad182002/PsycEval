import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Home from './components/Home';
import About from './components/About';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';
import {Route,Routes} from 'react-router';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Logout from './components/Logout';
import ProtectedRoute from './ProtectedRoute';
import Personalinfo from './components/Personalinfo';
import Games from './components/Games';
import Memorygame from './components/Memorygame';
import Mood from './components/Mood';
import Quiz from './components/Quiz';
import Quiz1 from './components/Quiz1';
import Teacher from  './components/Teacher';
import Quiz2 from './components/Quiz2';

function App() {
  return (
    <>
    <Navbar/>
    <Routes>
      <Route  path ="/" element = {<Home/>} />
      <Route  path  ="/about" element = {<About/>} />
      <Route   path ="/service" element = {<Services/>} />
      <Route  path  ="/contact" element = {<Contact/>} />
      <Route   path ="/login" element = {<Login/>} />
      <Route   path ="/register" element = {<Register/>} />
      <Route   path ="/dashboard" element = {<Dashboard/>} />
      <Route  path  ="/logout" element = {<Logout/>} />
      <Route  path  ="/Personalinfo" element = {<Personalinfo/>} />
      <Route  path  ="/games" element = {<Games/>} />
      <Route  path  ="/memorygame" element = {<Memorygame/>} />
      <Route  path  ="/mood" element = {<Mood/>} />
      <Route  path  ="/quiz" element = {<Quiz/>} />
      <Route  path  ="/quiz1" element = {<Quiz1/>} />
      <Route  path  ="/teacher" element = {<Teacher/>} />
      <Route  path  ="/quiz2" element = {<Quiz2/>} />
    </Routes>
    <Footer/>
    </>
  );
}

export default App;
