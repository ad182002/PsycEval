import React,{useState} from 'react'
import { NavLink } from 'react-router-dom';

const Quiz2 = () =>  {

    const [showFinalResult ,setFinalResult ]  = useState(false)
    const [score,setScore] = useState(0);
    const[currentQuestion,setCurrentQuestion] = useState(0);


    const questions = [
        {
          text: "Do you worry about lots of different things ",
          options: [
            { id: 0, text: "Never", isCorrect: false },
            { id: 1, text: "Rarely", isCorrect: false },
            { id: 2, text: "Sometimes", isCorrect: false },
            { id: 3, text: "Often", isCorrect: true },
          ],
        },
        {
          text: "Do you have trouble controlling your worries?",
          options: [
            { id: 0, text: "Never", isCorrect: false },
            { id: 1, text: "Rarely", isCorrect: false },
            { id: 2, text: "Sometimes", isCorrect: false },
            { id: 3, text: "Often", isCorrect: true },
          ],
        },
        {
          text: "Does worry or anxiety make it hard to concentrate?",
          options: [
            { id: 0, text: "Never", isCorrect: false },
            { id: 1, text: "Rarely", isCorrect: false },
            { id: 2, text: "Sometimes", isCorrect: false },
            { id: 3, text: "Often", isCorrect: true },
          ],
        },
        {
          text: "Do you worry about how well you do things?",
          options: [
            { id: 0, text: "Never", isCorrect: false },
            { id: 1, text: "Rarely", isCorrect: false },
            { id: 2, text: "Sometimes", isCorrect: false },
            { id: 3, text: "Often", isCorrect: true },
          ],
        },
        {
          text: "Do you worry about things working out in the future?",
          options: [
            { id: 0, text: "Never", isCorrect: false },
            { id: 1, text: "Rarely", isCorrect: false },
            { id: 2, text: "Sometimes", isCorrect: false },
            { id: 3, text: "Often", isCorrect: true },
          ],
        },
      ];

     const optionClicked = (isCorrect) => {
         if(isCorrect){
             setScore(score+1);
         }

         if(currentQuestion+1<questions.length){
            setCurrentQuestion(currentQuestion+1);
         }else{
             setFinalResult(true);
         }
         
     }

     const restarQuiz = () =>{
         setScore(0);
         setCurrentQuestion(0);
         setFinalResult(false);
     }

  return (
    <div>
       <h1 className='scr'>Quiz-2</h1> 

       
       
        {showFinalResult ? (

        <div className='final-result'>
        <h1 className='txt1'>Final Results </h1>
        <h2 className='txt1'>{questions.length} out of {questions.length} answered </h2>
        <button  onClick={()=>restarQuiz()} className='btn btn-outline-primary ms-auto px-4 rounded-pill '> Restart Test </button>
    </div>

        ):(

       <div className='question-card'>
          <h2 className='question-number'>Question {currentQuestion+1} out of {questions.length} </h2> 
          <h3 className='question-text'>{questions[currentQuestion].text} </h3>

          <ul>
          {questions[currentQuestion].options.map((option) => {
              return (
                <li className='lis'
                onClick={()=>optionClicked(option.isCorrect)}
                  key={option.id}
                  
                >
                  {option.text}
                </li>
              );
            })}
          </ul>
       </div>
        )}
    </div>
  );
};

export default Quiz2;