import React,{useState} from 'react'
import { NavLink } from 'react-router-dom';

const Quiz1 = () =>  {

    const [showFinalResult ,setFinalResult ]  = useState(false)
    const [score,setScore] = useState(0);
    const[currentQuestion,setCurrentQuestion] = useState(0);


    const questions = [
        {
          text: "Little interest or pleasure in doing things ?",
          options: [
            { id: 0, text: "Not at all", isCorrect: false },
            { id: 1, text: "Several days", isCorrect: false },
            { id: 2, text: "More than half of the days", isCorrect: false },
            { id: 3, text: "Nearly every day", isCorrect: true },
          ],
        },
        {
          text: "Feeling down, depressed, or hopeless",
          options: [
            { id: 0, text: "Not at all", isCorrect: false },
            { id: 1, text: "Several days", isCorrect: false },
            { id: 2, text: "More than half of the days", isCorrect: false },
            { id: 3, text: "Nearly every day", isCorrect: true },
          ],
        },
        {
          text: "Trouble falling or staying asleep, or sleeping too much",
          options: [
            { id: 0, text: "Not at all", isCorrect: false },
            { id: 1, text: "Several days", isCorrect: false },
            { id: 2, text: "More than half of the days", isCorrect: false },
            { id: 3, text: "Nearly every day", isCorrect: true },
          ],
        },
        {
          text: "Poor appetite or overeating",
          options: [
            { id: 0, text: "Not at all", isCorrect: false },
            { id: 1, text: "Several days", isCorrect: false },
            { id: 2, text: "More than half of the days", isCorrect: false },
            { id: 3, text: "Nearly every day", isCorrect: true },
          ],
        },
        {
          text: "Trouble concentrating on things, such as reading the newspaper or watching television ",
          options: [
            { id: 0, text: "Not at all", isCorrect: false },
            { id: 1, text: "Several days", isCorrect: false },
            { id: 2, text: "More than half of the days", isCorrect: false },
            { id: 3, text: "Nearly every day", isCorrect: true },
          ],
        },
      ];

     const optionClicked = (isCorrect) => {
         if(isCorrect){
             setScore(score+1);
         }

         if(currentQuestion+1<questions.length){
            setCurrentQuestion(currentQuestion+1);
         }else{
             setFinalResult(true);
         }
         
     }

     const restarQuiz = () =>{
         setScore(0);
         setCurrentQuestion(0);
         setFinalResult(false);
     }

  return (
    <div>
       <h1 className='scr'>Quiz-1</h1> 

       
       
        {showFinalResult ? (

        <div className='final-result'>
        <h1 className='txt1'>Final Results </h1>
        <h2 className='txt1'>{questions.length} out of {questions.length} answered </h2>
        <button  onClick={()=>restarQuiz()} className='btn btn-outline-primary ms-auto px-4 rounded-pill '> Restart Test </button>
    </div>

        ):(

       <div className='question-card'>
          <h2 className='question-number'>Question {currentQuestion+1} out of {questions.length} </h2> 
          <h3 className='question-text'>{questions[currentQuestion].text} </h3>

          <ul>
          {questions[currentQuestion].options.map((option) => {
              return (
                <li className='lis'
                onClick={()=>optionClicked(option.isCorrect)}
                  key={option.id}
                  
                >
                  {option.text}
                </li>
              );
            })}
          </ul>
       </div>
        )}
    </div>
  );
};

export default Quiz1;