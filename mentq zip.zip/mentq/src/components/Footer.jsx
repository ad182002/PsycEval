import React from 'react';

const Footer = () => {
  return (
    <section id = "ft">
    <footer class=" text-center " >
      <div class="text-center p-2 text-dark">© 2022 Copyright  </div>
      <div class="text-center p-2 text-muted" >Our tests are NOT diagnostic tools. Only a licensed mental-health practitioner or doctor can properly diagnose mental health conditions</div>
    </footer>
    </section>
  );
};

export default Footer;
