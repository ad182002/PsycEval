import React from 'react'
import { NavLink } from 'react-router-dom';

const Games = () =>{
  return (
    <div>
         <div className="container my-5 ">
        <div className="row mt-5 ">
          <div className="col-md-4 ">
            <div class="card p-2 ">
              <div class="text-center">
                <img src="/assets/mood1.png" alt="About" className="w-75 " />
              </div>
              <div class="card-body text-center">
                <h5 class="card-title">Mood Analyser </h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/mood"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-gamepad" aria-hidden="true"></i> Play
                </NavLink>
              </div>
            </div>
          </div>
          <div className="col-md-4 ">
            <div class="card p-3 ">
              <div class="text-center">
                <img src="/assets/memory1.png" alt="About" className="w-50 " />
              </div>
              ;
              <div class="card-body text-center">
                <h5 class="card-title">Memory Game</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/memorygame"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-gamepad" aria-hidden="true"></i> Play
                </NavLink>
              </div>
            </div>
          </div>
          <div className="col-md-4 ">
            <div class="card p-3 w-100">
              <div class="text-center">
                <img src="/assets/happy1.png" alt="About" className="w-50" />
              </div>
              ;
              <div class="card-body text-center">
                <h5 class="card-title">Games</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/login"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-gamepad" aria-hidden="true"></i> Games
                </NavLink>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Games