import React from 'react';
import { NavLink } from 'react-router-dom';

const Memorygame = () => {
  return (
    <div>
      hello 
    </div>
  );
};

export default Memorygame;
