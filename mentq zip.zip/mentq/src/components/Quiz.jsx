import React from 'react';
import { NavLink } from 'react-router-dom';

const Quiz = () => {
  return (
    <div>
      <div className="container my-5 py-5">
        <div class="card border-info mb-3">
          <div class="card-header">Quiz-1</div>
          <div class="card-body">
            <h5 class="card-title">3 Minute Depression Test </h5>
            <p class="card-text">
            quiz based on the Depression Screening Test . 
            </p>
            <NavLink
                  to="/quiz1"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
          </div>
        </div>
        <div class="card border-info mb-3">
          <div class="card-header">Quiz-2</div>
          <div class="card-body">
            <h5 class="card-title">Anxiety Test </h5>
            <p class="card-text">
            Uncontrollable and persistent anxiety that interferes with your daily life may indicate generalized anxiety disorder (GAD). Take this assessment to see if you have symptoms common in people with an anxiety disorder.
            </p>
            <NavLink
                  to="/quiz2"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
          </div>
        </div>
        <div class="card border-info mb-3">
          <div class="card-header">Quiz-3</div>
          <div class="card-body">
            <h5 class="card-title">Info card title</h5>
            <p class="card-text">
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </p>
            <NavLink
                  to="/login"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
          </div>
        </div>
        <div class="card border-info mb-3">
          <div class="card-header">Quiz-4</div>
          <div class="card-body">
            <h5 class="card-title">Info card title</h5>
            <p class="card-text">
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </p>
            <NavLink
                  to="/login"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
          </div>
        </div>
        <div class="card border-info mb-3">
          <div class="card-header">Quiz-5</div>
          <div class="card-body">
            <h5 class="card-title">Info card title</h5>
            <p class="card-text">
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </p>
            <NavLink
                  to="/login"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
