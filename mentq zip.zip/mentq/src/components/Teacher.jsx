import React from 'react'

const teacher = () => {

  return (
    <div>
      <div className="profiledef">
        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img
                src="/assets/profpic.png"
                alt="About"
                className="img-fluid rounded-start w-100"
              />
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">User Profile </h5>
                <form>
                  <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Username <i class="fa fa-user" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="Name Surname"
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Email <i class="fa fa-envelope" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="email@example.com"
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Date of Birth <i class="fa fa-calendar" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="date"
                        disabled = "true"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="email@example.com"
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                       Total Students <i class="fa fa-user-o" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="number"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="20"
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div className="container my-5 py-5">
            <div className='table1'>
        <table class="table align-middle mb-0 bg-white">
          <thead class="bg-info">
            <tr>
              <th>Name</th>
              <th>Details</th>
              <th></th>
              <th>Class</th>
              <th> progress</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <div class="d-flex align-items-center">
                  <img
                    src="/assets/profpic.png"
                    alt=""
                    class="rounded-circle w-25"
                  />
                  <div class="ms-3">
                    <p class="fw-bold mb-1">Name Surname</p>
                    <p class="text-muted mb-0">example@gmail.com</p>
                  </div>
                </div>
              </td>
              <td>
                <p class="fw-normal mb-1">DOB</p>
                <p class="text-muted mb-0">Guardian</p>
              </td>
              <td>
                <span class="badge badge-success rounded-pill d-inline">
                  Active
                </span>
              </td>
              <td>9-A</td>
              <td>
                <button type="button" class="btn btn-link btn-sm btn-rounded">
                  View
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <div class="d-flex align-items-center">
                  <img
                    src="/assets/profpic.png"
                    class="rounded-circle w-25"
                    alt=""
                  />
                  <div class="ms-3">
                    <p class="fw-bold mb-1">Name Surname </p>
                    <p class="text-muted mb-0">example@gmail.com</p>
                  </div>
                </div>
              </td>
              <td>
                <p class="fw-normal mb-1">DOB</p>
                <p class="text-muted mb-0">Guardian</p>
              </td>
              <td>
                <span class="badge badge-primary rounded-pill d-inline">
                  Onboarding
                </span>
              </td>
              <td>7-A</td>
              <td>
                <button
                  type="button"
                  class="btn btn-link btn-rounded btn-sm fw-bold"
                  data-mdb-ripple-color="dark"
                >
                  View
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <div class="d-flex align-items-center">
                  <img
                    src="/assets/profpic.png"
                    class="rounded-circle w-25"
                    alt=""
                  />
                  <div class="ms-3">
                    <p class="fw-bold mb-1">Name Surname</p>
                    <p class="text-muted mb-0">example@gmail.com</p>
                  </div>
                </div>
              </td>
              <td>
                <p class="fw-normal mb-1">DOB</p>
                <p class="text-muted mb-0">Grardian</p>
              </td>
              <td>
                <span class="badge badge-warning rounded-pill d-inline">
                  Awaiting
                </span>
              </td>
              <td>5-B</td>
              <td>
                <button
                  type="button"
                  class="btn btn-link btn-rounded btn-sm fw-bold"
                  data-mdb-ripple-color="dark"
                >
                  View
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      </div>
    </div>
  );
};

export default teacher;