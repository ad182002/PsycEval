import React from 'react';
import { NavLink } from 'react-router-dom';

const Mood= () => {
  return (
    <div>
        ,<section id ='mbg'>
      <section id = 'memorygame'>
          <section id = "txt">
        <h1 className="display-4 fw-bolder mb-4 text-center text-dark">How Are You Feeling ? </h1>
        </section>
      <div
        class="btn-group btn-group-lg "
        role="group"
        aria-label="Basic example"
      >
        <NavLink to="/dashboard" class="btn ">
          <img src="/assets/emoticon.png" alt="About" className="w-50 " />
        </NavLink>
        <NavLink to="/" class="btn ">
          <img src="/assets/happy.png" alt="About" className="w-50 " />
        </NavLink>
        <NavLink to="/" class="btn">
          <img src="/assets/happy.png" alt="About" className="w-50 " />
        </NavLink>
        <NavLink to="/" class="btn ">
          <img src="/assets/sad.png" alt="About" className="w-50 " />
        </NavLink>
        <NavLink to="/" class="btn ">
          <img src="/assets/stunned.png" alt="About" className="w-50 " />
        </NavLink>
      </div>
      </section>
      </section>
    </div>
  );
};

export default Mood;
