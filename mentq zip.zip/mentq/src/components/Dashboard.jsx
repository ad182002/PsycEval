import React from 'react';
import { NavLink } from 'react-router-dom';
import Contact from './Contact';
import Userprofile from './Userprofile';

const Dashboard = () => {
  return (
    <div>
      <div className="profiledef">
        <div class="card mb-3">
          <div class="row g-0">
            <div class="col-md-4">
              <img
                src="/assets/profpic.png"
                alt="About"
                className="img-fluid rounded-start w-100"
              />
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">User Profile </h5>
                <form>
                  <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Username <i class="fa fa-user" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="Rohan Kumar "
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Email <i class="fa fa-envelope" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="rohan2@gmail.com"
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                      Date of Birth <i class="fa fa-calendar" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        disabled = "true"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="20-06-2008"
                      />
                    </div>
                    <label for="staticEmail" class="col-sm-2 col-form-label">
                       Guardian Email <i class="fa fa-envelope" aria-hidden="true"></i>
                    </label>
                    <div class="col-sm-10">
                      <input
                        type="text"
                        readonly
                        class="form-control-plaintext"
                        id="staticEmail"
                        value="Raj23@gmail.com"
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <section id="Info">
        <div className="container my-5 py-5">
          <div className="row">
            <div className="col-md-6">
              
            </div>
          </div>
        </div>
      </section>
      <div className='pro'>
      <div className='container '>
      <h1 className='phead'>Progress Made </h1>
      <h6>Test Remaning 4/10 </h6>
      <div class="progress">
        
    <div class="progress-bar progress-bar-striped progress-bar-animated bg-warning w-50">
        6 total test taken
    </div>
    
</div>
<h6>Test Taken 6/10 </h6>
<div class="progress">
    <div class="progress-bar progress-bar-striped progress-bar-animated bg-danger w-75">
        <p> 6 total test taken</p>
    </div>
    
</div>
<h6>Test available 10/10</h6>
<div class="progress">
    <div class="progress-bar progress-bar-striped progress-bar-animated bg-success w-100">
        10 total test taken
    </div>
    
</div>


      </div >
      </div>
      <div className='dsh'>
      <div className="container my-5 ">
        <div className="row mt-5 ">
          <div className="col-md-4 ">
            <div class="card p-2 ">
              <div class="text-center">
                <img src="/assets/profile1.png" alt="About" className="w-75 " />
              </div>
              <div class="card-body text-center">
                <h5 class="card-title">Add personal Information</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/Personalinfo"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-user-plus" aria-hidden="true"></i> Add Info
                </NavLink>
              </div>
            </div>
          </div>
          <div className="col-md-4 ">
            <div class="card p-2 ">
              <div class="text-center">
                <img src="/assets/quiz1.png" alt="About" className="w-50 " />
              </div>
              ;
              <div class="card-body text-center">
                <h5 class="card-title">Quiz</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/quiz"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-question" aria-hidden="true"></i> Quiz{' '}
                </NavLink>
              </div>
            </div>
          </div>
          <div className="col-md-4 ">
            <div class="card p-3 w-100">
              <div class="text-center">
                <img src="/assets/happy1.png" alt="About" className="w-50" />
              </div>
              ;
              <div class="card-body text-center">
                <h5 class="card-title">Games</h5>
                <p class="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <NavLink
                  to="/games"
                  className="btn btn-outline-primary ms-auto px-4 rounded-pill "
                >
                  <i class="fa fa-gamepad" aria-hidden="true"></i> Games
                </NavLink>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      
    </div>
  );
};

export default Dashboard;
